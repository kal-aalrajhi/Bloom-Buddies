import SwiftUI

struct Dashboard: View {
    let imageNames = ["cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal", "cartoonKal"]
    
    let badgeImageNames = ["sprout", "sprout", "sprout", "sprout", "sprout", "sprout"]
    
    @State private var currentPage = 0
    
    var body: some View {
        ZStack {
            Color("FloralWhite")
                    .ignoresSafeArea()   
            ScrollView {
                VStack(alignment: .center, spacing: 20) {
                    Image("cartoonKal")
                        .resizable()
                        .frame(width: 120, height: 120)
                        .cornerRadius(60)
                        .overlay(
                            RoundedRectangle(cornerRadius: 60)
                                .stroke(Color.orange, lineWidth: 5)
                        )
                    
                    Text("CartoonKal2023")
                        .fontWeight(.heavy)
                        .font(.system(size: 20))
                        .frame(width: 200, height: 50)
                        .background(Color("Darkgreen"))
                        .cornerRadius(10)
                    
                    VStack(alignment: .leading, spacing: 5) {
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), ], spacing: 10) {
                            ForEach(badgeImageNames.indices, id: \.self) { index in
                                Image(badgeImageNames[index])
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 30, height: 30)
                                    .cornerRadius(5)
                            }
                        }
                    }
                    .padding(.leading, 5)
                    
                    Text("Interests:")
                        .font(.headline)
                        .frame(width: 200, height: 50)
                        .background(Color("Darkgreen"))
                        .cornerRadius(10)
                    
                    Rectangle()
                        .fill(Color("Darkgreen"))
                        .frame(width: 400, height: 150)
                        .cornerRadius(10)
                        .overlay(
                            VStack {
                                Text("Connections")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.top)
                                
                                ScrollView(.horizontal, showsIndicators: false) {
                                    LazyHStack(spacing: 10) {
                                        ForEach(imageNames.indices, id: \.self) { index in
                                            Image(imageNames[index])
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .frame(width: 90, height: 90)
                                                .cornerRadius(10)
                                                .scaledToFit()
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 10)
                                                        .stroke(Color.white, lineWidth: 3)
                                                )
                                        }
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        )
                    
                    Spacer()
                }
                .padding()
                .foregroundColor(Color("FloralWhite"))
            }
        }
    }
}

struct Dashboard_Previews: PreviewProvider {
    static var previews: some View {
        Dashboard()
    }
}
