//
//  SearchEvents.swift
//  Bloom Buds
//
//  Created by Amber Spencley on 5/11/23.
//

import SwiftUI

struct SearchEvents: View {
    @State private var searchEvents: String = ""
    @State private var gardeningInterests: String = ""
    @State private var filterLocation: String = ""
    var body: some View {
        VStack(alignment: .center) {
            Text("Search Events")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(Color("BlackOlive"))
            Spacer()
                .frame(height:50)
            
            CustomTextField(text: $searchEvents, placeholder: "Search Events", color: .white)
                .frame(width: 150, height: 3)
                .padding()
                .background(Color("Darkgreen"))
                .cornerRadius(10.0)
                .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
            CustomTextField(text: $gardeningInterests, placeholder: "Gardening Interests", color: .white)
                .frame(width: 150, height: 3)
                .padding()
                .background(Color("Tawny"))
                .cornerRadius(10.0)
                .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
            CustomTextField(text: $filterLocation, placeholder: "Filter by Location", color: .white)
                .frame(width: 150, height: 3)
                .padding()
                .background(Color("Tawny"))
                .cornerRadius(10.0)
                .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            Spacer()
                .frame(height:50)
            
            HStack {
                
                Button("Jake's Vermicomposting"){
                    
                }
                .frame(width: 150, height: 50)
                .padding()
                .background(Color("Asparagus"))
                .cornerRadius(10.0)
                .multilineTextAlignment(.center)
                .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                
                Button("Alex's Raised Bed Garden"){
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .frame(width: 150, height: 50)
                .padding()
                .background(Color("Asparagus"))
                .cornerRadius(10.0)
                .multilineTextAlignment(.center)
                .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            }
            .foregroundColor(Color("FloralWhite"))
            VStack(alignment: .center) {
                HStack {
                    Button("Zach's Companion Planting"){
                        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                    }
                    .frame(width: 150, height: 50)
                    .padding()
                    .background(Color("Asparagus"))
                    .cornerRadius(10.0)
                    .multilineTextAlignment(.center)
                    .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    
                    Button("Kacie's Soil Amendment"){
                        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                    }
                    .frame(width: 150, height: 50)
                    .padding()
                    .background(Color("Asparagus"))
                    .cornerRadius(10.0)
                    .multilineTextAlignment(.center)
                    .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                }
                
            }
            .foregroundColor(Color("FloralWhite"))
            
        }
        
        
    }
    
    
    
}

struct SearchEvents_Previews: PreviewProvider {
    static var previews: some View {
        SearchEvents()
    }
}
