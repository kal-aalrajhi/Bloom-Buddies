//
//  Bloom_BuddiesApp.swift
//  Bloom Buddies
//
//  Created by Kal Circus on 5/8/23.
//

import SwiftUI

@main
struct Bloom_BuddiesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
//            Dashboard()
        }
    }
}
